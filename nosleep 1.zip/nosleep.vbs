Set WshShell = CreateObject("WScript.Shell")

WshShell.Popup "No Sleep Activated", 3, "Keep Awake", 64

Do
	WshShell.SendKeys "{F15}"
	WScript.Sleep 90000
Loop